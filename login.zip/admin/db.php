<?php
$conn = mysqli_connect("localhost", "root", "", "form2");

if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}
?>